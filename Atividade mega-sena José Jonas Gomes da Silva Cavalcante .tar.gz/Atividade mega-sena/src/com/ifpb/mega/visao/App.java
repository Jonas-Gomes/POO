package com.ifpb.mega.visao;

import static com.ifpb.mega.modelo.Jogo.FazerJogo;

public class App{

    public static void main(String[] args) {

        FazerJogo();

    }

}
